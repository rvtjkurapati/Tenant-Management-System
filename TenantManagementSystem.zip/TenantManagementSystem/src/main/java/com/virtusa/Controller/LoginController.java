package com.virtusa.Controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.Dto.Owner;
import com.virtusa.Dto.Tenant;
import com.virtusa.Service.IAdminServiceImpl;
import com.virtusa.Service.IOwnerServiceImpl;


@WebServlet("/Login")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public LoginController() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession sn=request.getSession();
		IOwnerServiceImpl owner= new IOwnerServiceImpl();
		IAdminServiceImpl admin= new IAdminServiceImpl();
		String action=request.getParameter("action");
		String target="";
		switch(action) {
		
		case "Log In":
		{
			String uname=request.getParameter("username");
			String pwd=request.getParameter("password");
			boolean val=owner.ValidateOwner(uname,pwd);
			target="";
			if(val==true)
			{	
				int id=owner.getOwnerId(uname);
				ArrayList<Tenant> tl=owner.getByOwner(id);
				sn.setAttribute("OpSelect", "All");
				sn.setAttribute("TList", tl);
				sn.setAttribute("oid", id);
				sn.setAttribute("uname", uname);
				sn.setAttribute("pwd", pwd);
				target="Homepage.jsp";
				
			}
			else
			{	
				target="index.jsp";
			}
				
			}
			break;
		
		
	case "LOG IN":
	{
		String uname=request.getParameter("username");
		String pwd=request.getParameter("password");
		boolean val=admin.ValidateAdmin(uname,pwd);
		target="";
		if(val==true)
		{
			sn.setAttribute("OpSelect", "All");
			ArrayList<Owner> tl=admin.getOwners();
			sn.setAttribute("OList", tl);
			sn.setAttribute("uname", uname);
			sn.setAttribute("pwd", pwd);
			target="Adminpage.jsp";
			
		}
		else
		{	
			target="index.jsp";
		}
			
		}
		break;
	}
		RequestDispatcher rd = request.getRequestDispatcher(target);
		rd.forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
