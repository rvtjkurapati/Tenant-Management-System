package com.virtusa.Controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.Dto.Owner;
import com.virtusa.Dto.Owner;
import com.virtusa.Service.IAdminServiceImpl;

@WebServlet("/Admin")
public class AdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public AdminController() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IAdminServiceImpl ats=new IAdminServiceImpl();
		HttpSession sn=request.getSession();
		
		String action=request.getParameter("action");
		String target="";
		
		switch(action) {
		
		case "Home":
		{
			ArrayList<Owner> tl=ats.getOwners();
			sn.setAttribute("OList", tl);	
			target="Adminpage.jsp";
		break;
		}
		case "modifyowner":
		{
			String oid=request.getParameter("oid");
			String uname=request.getParameter("uname");
			String pass=request.getParameter("pass");
			
			sn.setAttribute("oid", oid);	
			sn.setAttribute("uname", uname);	
			sn.setAttribute("pass", pass);	
			target="ModifyOwner.jsp";
			break;
			
		}
		
		case "updateowner":
		{
			int oid=Integer.parseInt(request.getParameter("oid"));
			String uname=request.getParameter("uname");
			String pass=request.getParameter("pass");
			Owner t=new Owner(oid,uname,pass);
			boolean book=ats.ModifyOwner(t);
			ArrayList<Owner> tl=ats.getOwners();
			sn.setAttribute("OList", tl);
			target="Adminpage.jsp";
			break;
		}	
		
		case "addowner":
		{
			String uname=request.getParameter("uname");
			String pass=request.getParameter("pass");
			Owner t=new Owner(0,uname,pass);
			boolean book=ats.addOwner(t);
			ArrayList<Owner> tl=ats.getOwners();
			sn.setAttribute("OList", tl);
			target="Adminpage.jsp";
			break;
		}	
		case "deleteowner":
		{
			int oid=Integer.parseInt(request.getParameter("oid"));
			boolean book=ats.delOwner(oid);
			ArrayList<Owner> tl=ats.getOwners();
			sn.setAttribute("OList", tl);
			target="Adminpage.jsp";
			break;
		}
		
		case "Search":
		{
			
			String name=request.getParameter("name");
			String op=request.getParameter("search");
			target="Adminpage.jsp";
			
			if(op.equals("All"))
			{
				ArrayList<Owner> tl=ats.getOwners();
				sn.setAttribute("OList", tl);	
				sn.setAttribute("OpSelect", "All");	
			}
			
			if(op.equals("Owner name"))
			{
				ArrayList<Owner> tl=ats.SearchOwner(name);
				sn.setAttribute("OList", tl);
				sn.setAttribute("OpSelect", "Owner name");	
			}
			if(op.equals("Owner Id"))
			{	
				int fid =Integer.parseInt(request.getParameter("name"));
				ArrayList<Owner> tl=ats.SearchOwner(fid);
				sn.setAttribute("OList", tl);	
				sn.setAttribute("OpSelect", "Owner Id");	
			}
			
			break;
		}
		}
		RequestDispatcher rd = request.getRequestDispatcher(target);
		rd.forward(request, response);
	}

	
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}


}
