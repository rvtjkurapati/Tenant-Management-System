package com.virtusa.Controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.Dto.Tenant;

import com.virtusa.Service.IOwnerServiceImpl;

@WebServlet("/Owner")
public class OwnerController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public OwnerController() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IOwnerServiceImpl ats=new IOwnerServiceImpl();
		HttpSession sn=request.getSession();
		
		String action=request.getParameter("action");
		String target="";
		
		switch(action) {
		
		case "Home":
		{	
			int id=Integer.parseInt(request.getParameter("oid"));
			sn.setAttribute("oid", id);
			ArrayList<Tenant> tl=ats.getByOwner(id);
			sn.setAttribute("TList", tl);	
			target="Homepage.jsp";
		break;
		}
		case "modifytenant":
		{
			String fno=request.getParameter("fno");
			String name=request.getParameter("name");
			String phone=request.getParameter("phone");
			String mail=request.getParameter("mail");
			String gender=request.getParameter("gender");
			int id=Integer.parseInt(request.getParameter("oid"));
			sn.setAttribute("oid", id);
			sn.setAttribute("fno", fno);	
			sn.setAttribute("name", name);	
			sn.setAttribute("phone", phone);	
			sn.setAttribute("mail", mail);	
			sn.setAttribute("gender", gender);
			target="ModifyTenant.jsp";
			break;
			
		}
		
		case "updatetenant":
		{
			int fno=Integer.parseInt(request.getParameter("fno"));
			String name=request.getParameter("name");
			String phone=request.getParameter("phone");
			String mail=request.getParameter("mail");
			String gender=request.getParameter("gender");
			int id=Integer.parseInt(request.getParameter("oid"));
			sn.setAttribute("oid", id);
			Tenant t=new Tenant(id,fno,name,phone,mail,gender);
			System.out.println(t);
			boolean book=ats.ModifyTenant(t);
			System.out.println(book);
			ArrayList<Tenant> tl=ats.getByOwner(id);
			sn.setAttribute("TList", tl);
			target="Homepage.jsp";
			break;
		}	
		
		case "addtenant":
		{
			int fno=Integer.parseInt(request.getParameter("fno"));
			String name=request.getParameter("name");
			String phone=request.getParameter("phone");
			String mail=request.getParameter("mail");
			String gender=request.getParameter("gender");
			int id=Integer.parseInt(request.getParameter("oid"));
			sn.setAttribute("oid", id);
			Tenant t=new Tenant(id,fno,name,phone,mail,gender);
			System.out.println(t);
			boolean book=ats.addTenant(id,t);
			System.out.println(book);
			ArrayList<Tenant> tl=ats.getByOwner(id);
			sn.setAttribute("TList", tl);
			target="Homepage.jsp";
			break;
		}	
		case "deletetenant":
		{
			int fno=Integer.parseInt(request.getParameter("fno"));
			boolean book=ats.delTenant(fno);
			System.out.println(book);
			int id=Integer.parseInt(request.getParameter("oid"));
			sn.setAttribute("oid", id);
			ArrayList<Tenant> tl=ats.getByOwner(id);
			sn.setAttribute("TList", tl);
			target="Homepage.jsp";
			break;
		}
		
		case "Search":
		{
			
			String name=request.getParameter("name");
			String op=request.getParameter("search");
			int id=Integer.parseInt(request.getParameter("oid"));
			sn.setAttribute("oid", id);
			target="Homepage.jsp";
			
			if(op.equals("All"))
			{
				ArrayList<Tenant> tl=ats.getByOwner(id);
				sn.setAttribute("TList", tl);	
				sn.setAttribute("OpSelect", "All");	
			}
			
			if(op.equals("Tenant name"))
			{
				ArrayList<Tenant> tl=ats.SearchTenant(name,id);
				sn.setAttribute("TList", tl);
				sn.setAttribute("OpSelect", "Tenant name");	
			}
			if(op.equals("Flat No"))
			{	
				int fid =Integer.parseInt(request.getParameter("name"));
				ArrayList<Tenant> tl=ats.SearchTenant(fid,id);
				sn.setAttribute("TList", tl);	
				sn.setAttribute("OpSelect", "Flat No");	
			}
			if(op.equals("Phone"))
			{
				ArrayList<Tenant> tl=ats.SearchByPhone(name,id);
				sn.setAttribute("TList", tl);	
				sn.setAttribute("OpSelect", "Phone");	
			}
			if(op.equals("Mail"))
			{
				ArrayList<Tenant> tl=ats.SearchByMail(name,id);
				sn.setAttribute("TList", tl);	
				sn.setAttribute("OpSelect", "Mail");	
			}
			if(op.equals("Gender"))
			{
				ArrayList<Tenant> tl=ats.SearchByGender(name,id);
				sn.setAttribute("TList", tl);	
				sn.setAttribute("OpSelect", "Gender");	
			}
			break;
		}
		
		}
		RequestDispatcher rd = request.getRequestDispatcher(target);
		rd.forward(request, response);
	}

	
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}


}
