package com.virtusa.Service;

import java.util.ArrayList;

import com.virtusa.Dao.IAdminDao;
import com.virtusa.Dto.Owner;

public class IAdminServiceImpl {
	
	
IAdminDao aat;
	
	public boolean ValidateAdmin(String uname,String pwd)
	{
		aat = new IAdminDao();
		return aat.ValidateAdmin(uname,pwd);
	}
		
	public boolean addOwner(Owner td){
		aat = new IAdminDao();
		return aat.AddOwner(td);
	}
	
		
		public boolean delOwner(int td){
			aat= new IAdminDao();
			return aat.DelOwner(td);
		}
		
		public ArrayList<Owner> getOwners(){
			aat= new IAdminDao();
			return aat.getOwners();
		}
		
		public boolean ModifyOwner(Owner t)
		{
			aat= new IAdminDao();
			return aat.ModifyOwner(t);
		}
		
		public ArrayList<Owner> SearchOwner(String str)
		{
			aat= new IAdminDao();
			return aat.SearchOwner(str);
		}
		
		public ArrayList<Owner> SearchOwner(int str)
		{
			aat= new IAdminDao();
			return aat.SearchOwner(str);
		}
		

}
