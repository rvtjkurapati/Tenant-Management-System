
package com.virtusa.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.virtusa.Dto.Tenant;
import com.virtusa.Util.DbConnection;
import com.virtusa.Dto.Tenant;

public class IOwnerDao {

	
	public boolean AddTenant(int id,Tenant t)
	{
		
		try {
			
			Connection con = DbConnection.getConnection();
			String cmd1="select * from tenant where phone=? and owner_id = ?";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ps1.setString(1,t.getPhone());
			ps1.setInt(2,id);
			ResultSet rs= ps1.executeQuery();
			
			String cmd3="select * from tenant where mail=? and owner_id = ?";
			PreparedStatement ps3 = con.prepareStatement(cmd3);
			ps3.setString(1,t.getMail());
			ps3.setInt(2,id);
			ResultSet rs3= ps3.executeQuery();
			
			if(!rs.next() && !rs3.next())
			{
				String cmd2="insert into Tenant values(?,?,?,?,?,?);";
				PreparedStatement ps2 = con.prepareStatement(cmd2);
				ps2.setInt(1,t.getOwnerId());
				ps2.setInt(2,t.getFlat());
				ps2.setString(3,t.getName());
				ps2.setString(4,t.getPhone());
				ps2.setString(5,t.getMail());
				ps2.setString(6,t.getGender());
				ps2.executeUpdate();
				return true;
			}
			
			else
			{	
				return false;
			}
			
		}
		catch(Exception e)
		{	
			System.out.println(e);
			e.getStackTrace();		
		}
		return false;
	}
	

	public boolean DelTenant(int s)
	{
		
		try {
			Connection con = DbConnection.getConnection();
			
			String cmd1="select * from tenant where flat_no=?";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ps1.setInt(1,s);
			ResultSet rs= ps1.executeQuery();
			if(rs.next())
			{
				String cmd2="delete from tenant where flat_no=?";
				PreparedStatement ps2 = con.prepareStatement(cmd2);
				ps2.setInt(1,s);
				ps2.executeUpdate();
				return true;
			}
			else
			{	
				return false;
			}
			
			
		}
		catch(Exception e)
		{
			e.getStackTrace();		
		}
		return false;
		
	}
	
	
	
	public ArrayList<Tenant> getTenants()
	{
		ArrayList<Tenant> log=new ArrayList<Tenant>();
		try
		{
			Connection con = DbConnection.getConnection();
			String cmd="select * from tenant";
			PreparedStatement ps = con.prepareStatement(cmd);
		
			ResultSet rs= ps.executeQuery();
			while(rs.next()) {
				int oid=rs.getInt(1);
				int fn= rs.getInt(2);
				String name= rs.getString(3);
				String phone= rs.getString(4);
				String mail= rs.getString(5);
				String gen= rs.getString(6);
				Tenant l=new Tenant(oid,fn,name,phone,mail,gen);
				log.add(l);
				
				}
			if(log.size()!=0)
			{	
				
				return log;	
			}
			else
			{
				return null;
			}
		}
		
		catch(Exception e)
		{
			e.getStackTrace();		
		}
		return null;
	}
	
	
	
	public boolean ModifyTenant(Tenant t)
	{
		
		try {
			Connection con = DbConnection.getConnection();
			String cmd1="select * from tenant where flat_no=?";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ps1.setInt(1,t.getFlat());
			ResultSet rs= ps1.executeQuery();
			
			String cmd2=" select count(phone) from tenant where  phone=? and flat_no!=?";
			PreparedStatement ps2 = con.prepareStatement(cmd2);
			ps2.setString(1,t.getPhone());
			ps2.setInt(2,t.getFlat());
			ResultSet rs2= ps2.executeQuery();
			int p=1;
			int e=1;
			while(rs2.next())
			{
				p=rs2.getInt(1);
			}
			
			String cmd3=" select count(mail) from tenant where mail=? and flat_no!=?";
			PreparedStatement ps3 = con.prepareStatement(cmd3);
			ps3.setString(1,t.getMail());
			ps3.setInt(2,t.getFlat());
			ResultSet rs3= ps3.executeQuery();
			while(rs3.next())
			{
				 e=rs3.getInt(1);
			}
			System.out.println(p);
			System.out.println(e);
			if(rs.next() && (p==0) && (e==0))
			{
			System.out.println(t.getName());
			String cmd="update  tenant  set tenant_name=? , phone=? , mail=? , gender=? where flat_no=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1,t.getName());
			ps.setString(2,t.getPhone());
			ps.setString(3,t.getMail());
			ps.setString(4,t.getGender());
			ps.setInt(5,t.getFlat());
			ps.executeUpdate();
			return true;
			}
			
			else
			{	
				return false;
			}
			
		}
		catch(Exception e)
		{
			System.out.println(e);
			e.getStackTrace();		
		}
		
		return false;
	}
		
	
	
	public ArrayList<Tenant> SearchTenant(String str,int id)
	{
		
		try {
			Connection con = DbConnection.getConnection();
			ArrayList<Tenant> log=new ArrayList<Tenant>();
			String cmd="select * from  tenant  where tenant_name like ? and owner_id=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1,str+"%");
			ps.setInt(2,id);
			ResultSet rs= ps.executeQuery();
			
			while(rs.next()) {
				int oid=rs.getInt(1);
				int fn= rs.getInt(2);
				String name= rs.getString(3);
				String phone= rs.getString(4);
				String mail= rs.getString(5);
				String gen= rs.getString(6);
				Tenant l=new Tenant(oid,fn,name,phone,mail,gen);
				log.add(l);
				
			}
			
			
			if(log.size()>0)
			{	
				
				return log;
			}
			
			else
			{
				
				return null;
			}
			
		}
		
		catch(Exception e)
		{
			e.getStackTrace();		
		}
		
		return null;
	}
	
	
	
	
	public ArrayList<Tenant> SearchTenant(int cid,int id)
	{
		
		try {
			Connection con = DbConnection.getConnection();
			ArrayList<Tenant> log=new ArrayList<Tenant>();
			String cmd="select * from  tenant  where flat_no=?  and owner_id=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setInt(1,cid);
			ps.setInt(2, id);
			ResultSet rs= ps.executeQuery();
			
			while(rs.next()) {
				int oid=rs.getInt(1);
				int fn= rs.getInt(2);
				String name= rs.getString(3);
				String phone= rs.getString(4);
				String mail= rs.getString(5);
				String gen= rs.getString(6);
				Tenant l=new Tenant(oid,fn,name,phone,mail,gen);
				log.add(l);
			}
			
			
			if(log.size()>0)
			{	
				
				return log;
			}
			
			else
			{
				
				return null;
			}
			
		}
		
		catch(Exception e)
		{
			e.getStackTrace();		
		}
		
		return null;
	}
	
	public ArrayList<Tenant> SearchByPhone(String str,int id)
	{
		
		try {
			Connection con = DbConnection.getConnection();
			ArrayList<Tenant> log=new ArrayList<Tenant>();
			String cmd="select * from  tenant  where phone like ?  and owner_id=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1,str+"%");
			ps.setInt(2,id);
			ResultSet rs= ps.executeQuery();
			
			while(rs.next()) {
				int oid=rs.getInt(1);
				int fn= rs.getInt(2);
				String name= rs.getString(3);
				String phone= rs.getString(4);
				String mail= rs.getString(5);
				String gen= rs.getString(6);
				Tenant l=new Tenant(oid,fn,name,phone,mail,gen);
				log.add(l);
				
			}
			
			
			if(log.size()>0)
			{	
				
				return log;
			}
			
			else
			{
				
				return null;
			}
			
		}
		
		catch(Exception e)
		{
			e.getStackTrace();		
		}
		
		return null;
	}
	
	
	public ArrayList<Tenant> SearchByMail(String str,int id)
	{
		
		try {
			Connection con = DbConnection.getConnection();
			ArrayList<Tenant> log=new ArrayList<Tenant>();
			String cmd="select * from  Tenant  where mail like ?  and owner_id=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1,str+"%");
			ps.setInt(2, id);
			ResultSet rs= ps.executeQuery();
			
			while(rs.next()) {
				int oid=rs.getInt(1);
				int fn= rs.getInt(2);
				String name= rs.getString(3);
				String phone= rs.getString(4);
				String mail= rs.getString(5);
				String gen= rs.getString(6);
				Tenant l=new Tenant(oid,fn,name,phone,mail,gen);
				log.add(l);
				
			}
			
			
			if(log.size()>0)
			{	
				
				return log;
			}
			
			else
			{
				
				return null;
			}
			
		}
		
		catch(Exception e)
		{
			e.getStackTrace();		
		}
		
		return null;
	}
	
	
	public ArrayList<Tenant> SearchByGender(String str,int id)
	{
		
		try {
			Connection con = DbConnection.getConnection();
			ArrayList<Tenant> log=new ArrayList<Tenant>();
			String cmd="select * from  tenant  where gender like ?  and owner_id=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1,str+"%");
			ps.setInt(2, id);
			ResultSet rs= ps.executeQuery();
			
			while(rs.next()) {
				int oid=rs.getInt(1);
				int fn= rs.getInt(2);
				String name= rs.getString(3);
				String phone= rs.getString(4);
				String mail= rs.getString(5);
				String gen= rs.getString(6);
				Tenant l=new Tenant(oid,fn,name,phone,mail,gen);
				log.add(l);
				
			}
			
			
			if(log.size()>0)
			{	
				
				return log;
			}
			
			else
			{
				
				return null;
			}
			
		}
		
		catch(Exception e)
		{
			e.getStackTrace();		
		}
		
		return null;
	}
	public ArrayList<Tenant> getByOwner(int str)
	{
		
		try {
			Connection con = DbConnection.getConnection();
			ArrayList<Tenant> log=new ArrayList<Tenant>();
			String cmd="select * from  tenant  where owner_id= ?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setInt(1,str);
			ResultSet rs= ps.executeQuery();
			
			while(rs.next()) {
				int oid=rs.getInt(1);
				int fn= rs.getInt(2);
				String name= rs.getString(3);
				String phone= rs.getString(4);
				String mail= rs.getString(5);
				String gen= rs.getString(6);
				Tenant l=new Tenant(oid,fn,name,phone,mail,gen);
				log.add(l);
				
			}
			
			
			if(log.size()>0)
			{	
				
				return log;
			}
			
			else
			{
				
				return null;
			}
			
		}
		
		catch(Exception e)
		{
			System.out.println(e);
			e.getStackTrace();		
		}
		
		return null;
	}
	
	public boolean ValidateOwner(String uname,String pwd)
	{
		
		try {
			Connection con = DbConnection.getConnection();
			String cmd="select * from owner where uname=? and pass=?;";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1,uname);
			ps.setString(2,pwd);
			ResultSet rs= ps.executeQuery();
			if(rs.next())
			{	
				return true;
			}
			else
			{	
				return false;
			}
			
		}
		catch(Exception e)
		{
			e.getStackTrace();		
		}
		
		return false;
	}
	
	public int getOwnerId(String uname)
	{
		
		try {
			Connection con = DbConnection.getConnection();
			String cmd="select owner_id from owner where uname=?;";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1,uname);
			ResultSet rs= ps.executeQuery();
			if(rs.next())
			{	
				int oid=rs.getInt(1);
				return oid;
			}
			else
			{	
				return 0;
			}
			
		}
		catch(Exception e)
		{
			e.getStackTrace();		
		}
		
		return 0;
	}
	
}


