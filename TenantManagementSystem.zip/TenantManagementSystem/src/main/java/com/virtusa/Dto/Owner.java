package com.virtusa.Dto;

public class Owner {
	
	int ownerId;
	String uname;
	String pass;
	public Owner() {
		super();
	}
	public Owner(int ownerId, String unmae, String pass) {
		super();
		this.ownerId = ownerId;
		this.uname = unmae;
		this.pass = pass;
	}
	public int getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String unmae) {
		this.uname = unmae;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	@Override
	public String toString() {
		return "Owner [ownerId=" + ownerId + ", uname=" + uname + ", pass=" + pass + "]";
	}
	
	

}
