package com.virtusa.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.virtusa.Dto.Owner;
import com.virtusa.Util.DbConnection;

public class IAdminDao {
	

	public boolean AddOwner(Owner t)
	{
		
		try {
			
			Connection con = DbConnection.getConnection();
			String cmd1="select * from owner where uname=?";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ps1.setString(1,t.getUname());
			ResultSet rs= ps1.executeQuery();
			
			if(!rs.next())
			{
				String cmd2="insert into owner(uname,pass) values(?,?);";
				PreparedStatement ps2 = con.prepareStatement(cmd2);
				ps2.setString(1,t.getUname());
				ps2.setString(2,t.getPass());
				ps2.executeUpdate();
				return true;
			}
			
			else
			{	
				return false;
			}
			
		}
		catch(Exception e)
		{	
			System.out.println(e);
			e.getStackTrace();		
		}
		return false;
	}
	

	public boolean DelOwner(int s)
	{
		
		try {
			Connection con = DbConnection.getConnection();
			
			String cmd1="select * from owner where owner_id=?";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ps1.setInt(1,s);
			ResultSet rs= ps1.executeQuery();
			if(rs.next())
			{
				String cmd2="delete from owner where owner_id=?";
				PreparedStatement ps2 = con.prepareStatement(cmd2);
				ps2.setInt(1,s);
				ps2.executeUpdate();
				return true;
			}
			else
			{	
				return false;
			}
			
			
		}
		catch(Exception e)
		{
			e.getStackTrace();		
		}
		return false;
		
	}
	
	
	
	public ArrayList<Owner> getOwners()
	{
		ArrayList<Owner> log=new ArrayList<Owner>();
		try
		{
			Connection con = DbConnection.getConnection();
			String cmd="select * from owner";
			PreparedStatement ps = con.prepareStatement(cmd);
		
			ResultSet rs= ps.executeQuery();
			while(rs.next()) {
				int oid=rs.getInt(1);
				String uname= rs.getString(2);
				String pass= rs.getString(3);
				Owner l=new Owner(oid,uname,pass);
				log.add(l);
				
				}
			if(log.size()!=0)
			{	
				
				return log;	
			}
			else
			{
				return null;
			}
		}
		
		catch(Exception e)
		{
			e.getStackTrace();		
		}
		return null;
	}
	
	
	
	public boolean ModifyOwner(Owner t)
	{
		
		try {
			Connection con = DbConnection.getConnection();
			String cmd1="select * from owner where owner_id=?";
			PreparedStatement ps1 = con.prepareStatement(cmd1);
			ps1.setInt(1,t.getOwnerId());
			ResultSet rs= ps1.executeQuery();
			
			if(rs.next())
			{
			String cmd="update  owner  set uname=? , pass=?  where owner_id=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1,t.getUname());
			ps.setString(2,t.getPass());
			ps.setInt(3,t.getOwnerId());
			ps.executeUpdate();
			return true;
			}
			
			else
			{	
				return false;
			}
			
		}
		catch(Exception e)
		{
			System.out.println(e);
			e.getStackTrace();		
		}
		
		return false;
	}
		
	
	
	public ArrayList<Owner> SearchOwner(String str)
	{
		
		try {
			Connection con = DbConnection.getConnection();
			ArrayList<Owner> log=new ArrayList<Owner>();
			String cmd="select * from  owner  where uname like ?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1,str+"%");
			ResultSet rs= ps.executeQuery();
			
			while(rs.next()) {
				int oid=rs.getInt(1);
				String uname= rs.getString(2);
				String pass= rs.getString(3);
				Owner l=new Owner(oid,uname,pass);
				log.add(l);
				
			}
			
			
			if(log.size()>0)
			{	
				
				return log;
			}
			
			else
			{
				
				return null;
			}
			
		}
		
		catch(Exception e)
		{
			e.getStackTrace();		
		}
		
		return null;
	}
	
	
	
	
	public ArrayList<Owner> SearchOwner(int cid)
	{
		
		try {
			System.out.println(cid);
			Connection con = DbConnection.getConnection();
			ArrayList<Owner> log=new ArrayList<Owner>();
			String cmd="select * from  owner  where owner_id=?";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setInt(1,cid);
			ResultSet rs= ps.executeQuery();
			
			while(rs.next()) {
				int oid=rs.getInt(1);
				String uname= rs.getString(2);
				String pass= rs.getString(3);
				Owner l=new Owner(oid,uname,pass);
				log.add(l);
				System.out.println(log);
			}
			
			
			if(log.size()>0)
			{	
				
				return log;
			}
			
			else
			{
				
				return null;
			}
			
		}
		
		catch(Exception e)
		{
			System.out.println(e);
			e.getStackTrace();		
		}
		
		return null;
	}
	
	
	
	
	public boolean ValidateAdmin(String uname,String pwd)
	{
		
		try {
			Connection con = DbConnection.getConnection();
			String cmd="select * from admin where uname=? and pass=?;";
			PreparedStatement ps = con.prepareStatement(cmd);
			ps.setString(1,uname);
			ps.setString(2,pwd);
			ResultSet rs= ps.executeQuery();
			if(rs.next())
			{	
				return true;
			}
			else
			{	
				return false;
			}
			
		}
		catch(Exception e)
		{
			e.getStackTrace();		
		}
		
		return false;
	}

}
