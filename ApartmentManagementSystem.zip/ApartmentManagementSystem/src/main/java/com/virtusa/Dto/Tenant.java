
package com.virtusa.Dto;

public class Tenant {
	int ownerId;
	int flat;
    String name;
    String phone;
    String mail;
    String gender;
	public Tenant() {
		super();
	}
	public Tenant(int ownerId, int flat, String name, String phone, String mail, String gender) {
		super();
		this.ownerId = ownerId;
		this.flat = flat;
		this.name = name;
		this.phone = phone;
		this.mail = mail;
		this.gender = gender;
	}
	public int getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}
	public int getFlat() {
		return flat;
	}
	public void setFlat(int flat) {
		this.flat = flat;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	@Override
	public String toString() {
		return "Tenant [ownerId=" + ownerId + ", flat=" + flat + ", name=" + name + ", phone=" + phone + ", mail="
				+ mail + ", gender=" + gender + "]";
	}
	
	
    
}
