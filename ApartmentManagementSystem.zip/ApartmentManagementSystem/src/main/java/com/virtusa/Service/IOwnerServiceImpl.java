package com.virtusa.Service;

import java.util.ArrayList;

import com.virtusa.Dao.IOwnerDao;
import com.virtusa.Dto.Tenant;

public class IOwnerServiceImpl {
	IOwnerDao aat;
	
	public boolean ValidateOwner(String uname,String pwd)
	{
		aat = new IOwnerDao();
		return aat.ValidateOwner(uname,pwd);
	}
		
	public boolean addTenant(int s,Tenant td){
		aat = new IOwnerDao();
		return aat.AddTenant(s,td);
	}
	public ArrayList<Tenant> getByOwner(int td){
		aat= new IOwnerDao();
		return aat.getByOwner(td);
	}
	public int getOwnerId(String uname)
	{
		aat= new IOwnerDao();
		return aat.getOwnerId(uname);
	}
		public boolean delTenant(int td){
			aat= new IOwnerDao();
			return aat.DelTenant(td);
		}
		
		public ArrayList<Tenant> getTenants(){
			aat= new IOwnerDao();
			return aat.getTenants();
		}
		
		public boolean ModifyTenant(Tenant t)
		{
			aat= new IOwnerDao();
			return aat.ModifyTenant(t);
		}
		
		public ArrayList<Tenant> SearchTenant(String str,int id)
		{
			aat= new IOwnerDao();
			return aat.SearchTenant(str,id);
		}
		
		public ArrayList<Tenant> SearchTenant(int str,int id)
		{
			aat= new IOwnerDao();
			return aat.SearchTenant(str,id);
		}
		
		public ArrayList<Tenant> SearchByPhone(String str,int id)
		{
			aat= new IOwnerDao();
			return aat.SearchByPhone(str,id);
		}
		
		public ArrayList<Tenant> SearchByMail(String str,int id)
		{
			aat= new IOwnerDao();
			return aat.SearchByMail(str,id);
		}
		
		public ArrayList<Tenant> SearchByGender(String str,int id)
		{
			aat= new IOwnerDao();
			return aat.SearchByGender(str,id);
		}
		
}

